package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import DBConnection.DBConnect;
import Model.Product;
import Rule.KetLuan;
public class ProductDAO {
	private Connection conn=DBConnect.createConnection();
	private PreparedStatement preparedStatement;
	public ArrayList<Product> listProductOfAdvisory(ArrayList<KetLuan> ketLuans,int gioi_tinh)
	{
		ArrayList<Product> products= new ArrayList<Product>();
		ResultSet resultSet;
		try {
			String str="";
			for(KetLuan ketLuan:ketLuans)
			{
				str+=",'"+ketLuan.getSize()+"'";
			}
			if(gioi_tinh==1)
			{
				gioi_tinh=7;
			}
			else
			{
				gioi_tinh=8;
			}
			preparedStatement=conn.prepareStatement("select * from products  INNER JOIN categories on categories.id=products.category_id INNER JOIN group_category on categories.group_category_id=group_category.id  where size in ("+str.substring(1)+") and  group_category.id=?");
			preparedStatement.setInt(1, gioi_tinh);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next())
			{
				Product product=new Product();
				product.setId(resultSet.getInt("id"));
				product.setCategory_id(resultSet.getInt("category_id"));
				product.setName(resultSet.getString("name"));
				product.setImage(resultSet.getString("image"));
				product.setSize(resultSet.getString("size"));
				product.setDecription(resultSet.getString("decription"));
				product.setPrice(resultSet.getInt("price"));
				product.setDate(resultSet.getDate("date"));
				product.setView(resultSet.getInt("view"));
				product.setHighlights(resultSet.getString("highlights"));
				products.add(product);
			}
			return products;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public ArrayList<Product> listProductOfCategory(int id)
	{
		ArrayList<Product> products= new ArrayList<Product>();
		ResultSet resultSet;
		try {
			preparedStatement=conn.prepareStatement("select * from products where category_id=?");
			preparedStatement.setInt(1, id);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next())
			{
				Product product=new Product();
				product.setId(resultSet.getInt("id"));
				product.setCategory_id(resultSet.getInt("category_id"));
				product.setName(resultSet.getString("name"));
				product.setImage(resultSet.getString("image"));
				product.setSize(resultSet.getString("size"));
				product.setDecription(resultSet.getString("decription"));
				product.setPrice(resultSet.getInt("price"));
				product.setDate(resultSet.getDate("date"));
				product.setView(resultSet.getInt("view"));
				product.setHighlights(resultSet.getString("highlights"));
				products.add(product);
			}
			return products;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public ArrayList<Product> search(String name)
	{
		ArrayList<Product> products= new ArrayList<Product>();
		ResultSet resultSet;
		try {
			preparedStatement=conn.prepareStatement("select * from products where name LIKE ?");
			preparedStatement.setString(1, "%"+name+"%");
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next())
			{
				Product product=new Product();
				product.setId(resultSet.getInt("id"));
				product.setCategory_id(resultSet.getInt("category_id"));
				product.setName(resultSet.getString("name"));
				product.setImage(resultSet.getString("image"));
				product.setSize(resultSet.getString("size"));
				product.setDecription(resultSet.getString("decription"));
				product.setPrice(resultSet.getInt("price"));
				product.setDate(resultSet.getDate("date"));
				product.setView(resultSet.getInt("view"));
				product.setHighlights(resultSet.getString("highlights"));
				products.add(product);
			}
			return products;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public ArrayList<Product> listProduct()
	{
		ArrayList<Product> products= new ArrayList<Product>();
		ResultSet resultSet;
		try {
			preparedStatement=conn.prepareStatement("select * from products");
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next())
			{
				Product product=new Product();
				product.setId(resultSet.getInt("id"));
				product.setCategory_id(resultSet.getInt("category_id"));
				product.setName(resultSet.getString("name"));
				product.setImage(resultSet.getString("image"));
				product.setSize(resultSet.getString("size"));
				product.setDecription(resultSet.getString("decription"));
				product.setPrice(resultSet.getInt("price"));
				product.setDate(resultSet.getDate("date"));
				product.setView(resultSet.getInt("view"));
				product.setHighlights(resultSet.getString("highlights"));
				products.add(product);
			}
			return products;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public Product getProduct(int id)
	{
		Product product=new Product();
		ResultSet resultSet;
		try {
			preparedStatement=conn.prepareStatement("select * from products where id=?");
			preparedStatement.setInt(1, id);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next())
			{
				product.setId(resultSet.getInt("id"));
				product.setCategory_id(resultSet.getInt("category_id"));
				product.setName(resultSet.getString("name"));
				product.setImage(resultSet.getString("image"));
				product.setSize(resultSet.getString("size"));
				product.setDecription(resultSet.getString("decription"));
				product.setPrice(resultSet.getInt("price"));
				product.setDate(resultSet.getDate("date"));
				product.setView(resultSet.getInt("view"));
				product.setHighlights(resultSet.getString("highlights"));
			}
			return product;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public boolean insert(Product product)
	{
		try {
			preparedStatement=conn.prepareStatement("INSERT INTO `products`(`category_id`, `name`, `image`, `size`, `decription`, `price`, `date`, `highlights`) VALUES (?,?,?,?,?,?,?,?)");
			preparedStatement.setInt(1, product.getCategory_id());
			preparedStatement.setString(2, product.getName());
			preparedStatement.setString(3, product.getImage());
			preparedStatement.setString(4, product.getSize());
			preparedStatement.setString(5, product.getDecription());
			preparedStatement.setFloat(6, product.getPrice());
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date date = new Date();
			preparedStatement.setString(7, dateFormat.format(date));
			preparedStatement.setString(8, product.getHighlights());
			return preparedStatement.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean update(Product product)
	{
		try {
			preparedStatement=conn.prepareStatement("UPDATE `products` SET `category_id`=?,`name`=?,`image`=?,`size`=?,`decription`=?,`price`=?,`date`=?,`highlights`=? WHERE `id`=?");
			preparedStatement.setInt(1, product.getCategory_id());
			preparedStatement.setString(2, product.getName());
			preparedStatement.setString(3, product.getImage());
			preparedStatement.setString(4, product.getSize());
			preparedStatement.setString(5, product.getDecription());
			preparedStatement.setFloat(6, product.getPrice());
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date date = new Date();
			preparedStatement.setString(7, dateFormat.format(date));
			preparedStatement.setString(8, product.getHighlights());
			preparedStatement.setInt(9, product.getId());
			return preparedStatement.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public ArrayList<Product> get4Product(int id,int total)
	{
		ArrayList<Product> products= new ArrayList<Product>();
		ResultSet resultSet;
		try {
			preparedStatement=conn.prepareStatement("SELECT * FROM `products` INNER JOIN categories on categories.id=products.category_id INNER JOIN group_category on categories.group_category_id=group_category.id where group_category.id In(?) ORDER BY products.id DESC LIMIT 0,?");
			preparedStatement.setInt(1, id);
			preparedStatement.setInt(2, total);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next())
			{
				Product product=new Product();
				product.setId(resultSet.getInt("id"));
				product.setCategory_id(resultSet.getInt("category_id"));
				product.setName(resultSet.getString("name"));
				product.setImage(resultSet.getString("image"));
				product.setSize(resultSet.getString("size"));
				product.setDecription(resultSet.getString("decription"));
				product.setPrice(resultSet.getInt("price"));
				product.setDate(resultSet.getDate("date"));
				product.setView(resultSet.getInt("view"));
				product.setHighlights(resultSet.getString("highlights"));
				products.add(product);
			}
			return products;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public boolean delete(int id)
	{
		try {
			preparedStatement=conn.prepareStatement("delete from products where id=?");
			preparedStatement.setInt(1, id);
			return preparedStatement.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean updateView(int id)
	{
		try {
			preparedStatement=conn.prepareStatement("update products set view=view+1 where id=?");
			preparedStatement.setInt(1, id);
			return preparedStatement.execute();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	}
	
}
