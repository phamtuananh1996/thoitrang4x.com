package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import DBConnection.DBConnect;
import Model.News;

public class NewsDao {
	private PreparedStatement preparedStatement;
	private Connection connection=new DBConnect().createConnection();
	public ArrayList<News> listNews()
	{
		try {
			ArrayList<News> news=new ArrayList<>();
			preparedStatement=connection.prepareStatement("select * from news");
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				news.add(new News(resultSet.getInt("id"),resultSet.getString("title"),resultSet.getString("content"),resultSet.getString("image")));
			}
			return news;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public boolean insert(News news)
	{
		try {
			preparedStatement=connection.prepareStatement("INSERT INTO `news`(`title`, `content`, `image`) VALUES (?,?,?)");
			preparedStatement.setString(1, news.getTitle());
			preparedStatement.setString(2, news.getContent());
			preparedStatement.setString(3, news.getImage());
			return preparedStatement.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public boolean delete(int id)
	{
		try {
			preparedStatement=connection.prepareStatement("delete from news where id=?");
			preparedStatement.setInt(1, id);
			return preparedStatement.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public News getNews(int id)
	{
		try {
			preparedStatement=connection.prepareStatement("select * from news where id=?");
			preparedStatement.setInt(1, id);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			return (new News(resultSet.getInt("id"),resultSet.getString("title"),resultSet.getString("content"),resultSet.getString("image")));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public boolean update(News news)
	{
		try {
			preparedStatement=connection.prepareStatement("UPDATE `news` SET `title`=?,`content`=?,`image`=? WHERE id=?");
			preparedStatement.setString(1, news.getTitle());
			preparedStatement.setString(2, news.getContent());
			preparedStatement.setString(3, news.getImage());
			preparedStatement.setInt(4, news.getId());
			return preparedStatement.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
}
