package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import DBConnection.DBConnect;
import Model.Category;
import Model.GroupCategory;

public class GroupCategoryDao {
	private Connection conn=DBConnect.createConnection();
	private PreparedStatement preparedStatement;
	public ArrayList<GroupCategory> getList()
	{
		ArrayList<GroupCategory> groupCategories=new ArrayList<>();
		try {
			preparedStatement=conn.prepareStatement("select * from group_category");
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				groupCategories.add(new GroupCategory(resultSet.getInt("id"), resultSet.getString("name")));
			}
			return groupCategories;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public void delete(int id)
	{
		try {
			preparedStatement=conn.prepareStatement("delete from group_category where id=?");
			preparedStatement.setInt(1, id);
			preparedStatement.execute();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	public void insert(GroupCategory cat)
	{
		try {
			preparedStatement=conn.prepareStatement("insert into group_category(name) values(?)");
			preparedStatement.setString(1, cat.getName());
			preparedStatement.execute();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	public GroupCategory getGroupCategory(int id)
	{
		try {
			preparedStatement=conn.prepareStatement("select * from group_category where id=?");
			preparedStatement.setInt(1, id);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				return new GroupCategory(resultSet.getInt("id"),resultSet.getString("name"));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}
	public boolean update(GroupCategory groupCategory)
	{
		try {
			preparedStatement=conn.prepareStatement("update group_category set name=? where id=?");
			preparedStatement.setString(1, groupCategory.getName());
			preparedStatement.setInt(2, groupCategory.getId());
			return preparedStatement.execute();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	}
}
