package DAO;

import java.sql.*;
import java.util.ArrayList;

import DBConnection.DBConnect;
import Model.Category;

public class CategoryDAO {
	private Connection conn= DBConnect.createConnection();
	private PreparedStatement statement;
	public ArrayList<Category> getList()
	{
		ArrayList<Category> categories=new ArrayList<>();
		try {
			statement=conn.prepareStatement("select * from categories order By id DESC");
			ResultSet resultSet=statement.executeQuery();
			while(resultSet.next())
			{
				categories.add(new Category(resultSet.getInt("id"),resultSet.getString("name"),resultSet.getInt("group_category_id")));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return categories;
	}
	public void insert(Category cat)
	{
		try {
			statement=conn.prepareStatement("insert into categories(name,group_category_id) values(?,?)");
			statement.setString(1, cat.getName());
			statement.setInt(2, cat.getGroup_category_id());
			statement.execute();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	public void delete(int id)
	{
		try {
			statement=conn.prepareStatement("delete from categories where id=?");
			statement.setInt(1, id);
			statement.execute();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	public Category getCategory(int id)
	{
		try {
			statement=conn.prepareStatement("select * from categories where id=? ");
			statement.setInt(1, id);
			ResultSet resultSet=statement.executeQuery();
			while(resultSet.next())
			{
				return new Category(resultSet.getInt("id"),resultSet.getString("name"),resultSet.getInt("group_category_id"));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}
	//lấy category của 1 group
	public ArrayList<Category> getCategoryOfGroup(int id)
	{
		ArrayList<Category> categories=new ArrayList<>();
		try {
			statement=conn.prepareStatement("select * from categories where group_category_id=? ");
			statement.setInt(1, id);
			ResultSet resultSet=statement.executeQuery();
			while(resultSet.next())
			{
				categories.add(new Category(resultSet.getInt("id"),resultSet.getString("name"),resultSet.getInt("group_category_id")));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return categories;
	}
	public boolean update(Category category)
	{
		try {
			statement=conn.prepareStatement("update categories set name=?,group_category_id=? where id=?");
			statement.setString(1, category.getName());
			statement.setInt(2, category.getGroup_category_id());
			statement.setInt(3, category.getId());
			return statement.execute();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	}
}
