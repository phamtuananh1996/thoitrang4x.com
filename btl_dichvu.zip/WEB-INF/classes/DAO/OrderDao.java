package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import DBConnection.DBConnect;
import Model.Cart;
import Model.Order;
import Model.Product;

public class OrderDao {
	private PreparedStatement preparedStatement;
	private Connection conn=DBConnect.createConnection();
	private ArrayList<Order> orders=new ArrayList<>();
	private Order order=new Order();
	public int insert(Order order)
	{
		try {
			preparedStatement=conn.prepareStatement("INSERT INTO `order`(`name`, `phone`, `address`, `total`, `status`, `email`) VALUES (?,?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS);
			preparedStatement.setString(1, order.getName());
			preparedStatement.setString(2, order.getPhone());
			preparedStatement.setString(3, order.getAddress());
			preparedStatement.setInt(4, order.getTotal());
			preparedStatement.setInt(5, order.getStatus());
			preparedStatement.setString(6, order.getEmail());
			preparedStatement.executeUpdate();
			 ResultSet rs = preparedStatement.getGeneratedKeys();
             if(rs.next())
             {
                 return rs.getInt(1);
             }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	public boolean insertOrderDetail(int id_order,int id_product,int total)
	{
		try {
			preparedStatement=conn.prepareStatement("INSERT INTO `order_detail`(`id_order`, `id_product`, `total`) VALUES (?,?,?)");
			preparedStatement.setInt(1, id_order);
			preparedStatement.setInt(2,id_product);
			preparedStatement.setInt(3, total);
			return preparedStatement.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public ArrayList<Order> listOrder()
	{
		try {
			ArrayList<Order> orders=new ArrayList<>();
			preparedStatement=conn.prepareStatement("SELECT `id`, `name`, `phone`, `address`, `total`, `status`, `email` FROM `order`");
			ResultSet resultSet= preparedStatement.executeQuery();
			while(resultSet.next())
			{
				Order order=new Order();
				order.setId(resultSet.getInt("id"));
				order.setName(resultSet.getString("name"));
				order.setEmail(resultSet.getString("email"));
				order.setPhone(resultSet.getString("phone"));
				order.setAddress(resultSet.getString("address"));
				order.setStatus(resultSet.getInt("status"));
				order.setTotal(resultSet.getInt("total"));
				orders.add(order);
			}
			return orders;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public Order getOrder(int id)
	{
		try {
			preparedStatement=conn.prepareStatement("SELECT `id`, `name`, `phone`, `address`, `total`, `status`, `email` FROM `order` where id=?");
			preparedStatement.setInt(1, id);
			ResultSet resultSet= preparedStatement.executeQuery();
			Order order=new Order();
			while(resultSet.next())
			{
				order.setId(resultSet.getInt("id"));
				order.setName(resultSet.getString("name"));
				order.setEmail(resultSet.getString("email"));
				order.setPhone(resultSet.getString("phone"));
				order.setAddress(resultSet.getString("address"));
				order.setStatus(resultSet.getInt("status"));
				order.setTotal(resultSet.getInt("total"));
			}
			return order;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public ArrayList<Cart> listDetailOrder(int id)
	{
		try {
			ArrayList<Cart> Carts=new ArrayList<>();
			Product product =new Product();
			preparedStatement=conn.prepareStatement("select * from order_detail inner join products on order_detail.id_product=products.id where order_detail.id_order=?");
			preparedStatement.setInt(1, id);
			ResultSet resultSet= preparedStatement.executeQuery();
			while(resultSet.next())
			{
				product.setId(resultSet.getInt("id"));
				product.setName(resultSet.getString("name"));
				product.setPrice(Integer.parseInt(resultSet.getString("price")));
				product.setImage(resultSet.getString("image"));
				Carts.add(new Cart(product,Integer.parseInt(resultSet.getString("total"))));
			}
			return Carts;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public boolean update(int id)
	{
		try {
			
			preparedStatement=conn.prepareStatement("update `order` set status=1 where id=?");
			preparedStatement.setInt(1, id);
			
			return preparedStatement.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
}
