package DAO;

import java.sql.*;
import java.util.ArrayList;

import DBConnection.DBConnect;
import MD5.MD5;
import Model.User;

public class UserDAO {
	private Connection conn=DBConnect.createConnection();
	private PreparedStatement preparedStatement;
	public User login(String email,String password)
	{	
		try {
			preparedStatement=conn.prepareStatement("select * from users where email=? and password=? and level=1");
			preparedStatement.setString(1, email);
			preparedStatement.setString(2, MD5.md5Java(password));
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				return new User(resultSet.getInt("id"),resultSet.getString("password"),resultSet.getString("email"),resultSet.getString("fullname"),resultSet.getInt("level"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public ArrayList<User> getList()
	{
		ArrayList<User> users= new ArrayList<User>();
		ResultSet resultSet;
		try {
			preparedStatement=conn.prepareStatement("select * from users");
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next())
			{
				User user=new User(resultSet.getInt("id"),resultSet.getString("password"),resultSet.getString("email"),resultSet.getString("fullname"),resultSet.getInt("level"));
				users.add(user);
			}
			return users;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public User getUser(String id)
	{
		ResultSet resultSet;
		try {
			preparedStatement=conn.prepareStatement("select * from users where id=?");
			preparedStatement.setString(1, id);
			resultSet = preparedStatement.executeQuery();
			User user=new User();
			while(resultSet.next())
			{
			  user=new User(resultSet.getInt("id"),resultSet.getString("password"),resultSet.getString("email"),resultSet.getString("fullname"),resultSet.getInt("level"));
			}
			return user;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public boolean update(User user)
	{
		try {
			preparedStatement=conn.prepareStatement("update users set email=?,password=?,fullname=?,level=1 where id=?");
			preparedStatement.setString(1, user.getEmail());
			preparedStatement.setString(2, MD5.md5Java(user.getPassword()));
			preparedStatement.setString(3, user.getFullName());
			preparedStatement.setInt(4, user.getId());
			return preparedStatement.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false; 
	}
	public boolean delete(int id)
	{
		try {
			preparedStatement=conn.prepareStatement("delete from users where id=?");
			preparedStatement.setInt(1, id);
			return preparedStatement.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false; 
	}
	public boolean insert(User user)
	{
		try {
			preparedStatement=conn.prepareStatement("insert into users (fullname,email,password,level)  values(?,?,?,1)");
			preparedStatement.setString(1, user.getFullName());
			preparedStatement.setString(2, user.getEmail());
			preparedStatement.setString(3, MD5.md5Java(user.getPassword()));
			return preparedStatement.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false; 
	}
}
