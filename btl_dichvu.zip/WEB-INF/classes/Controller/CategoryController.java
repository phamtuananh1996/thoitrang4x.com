package Controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import DAO.CategoryDAO;
import DAO.GroupCategoryDao;
import Model.Category;
import Model.GroupCategory;

/**
 * Servlet implementation class CategoryController
 */
@WebServlet("/admin/category")
public class CategoryController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CategoryController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		String action=(request.getParameter("action")==null)?"index":request.getParameter("action");
		RequestDispatcher dispatcher;
		CategoryDAO categoryDAO=new CategoryDAO();
		GroupCategoryDao groupCategoryDao=new GroupCategoryDao();
		switch (action) {
		case "add":
			request.setAttribute("group_category", groupCategoryDao.getList());
			dispatcher=request.getRequestDispatcher("/View/Admin/category/addcategory.jsp");
			dispatcher.forward(request, response);
			break;
		case "edit":
			request.setAttribute("group_category", groupCategoryDao.getList());
			request.setAttribute("category", categoryDAO.getCategory(Integer.parseInt(request.getParameter("id"))));
			dispatcher=request.getRequestDispatcher("/View/Admin/category/editcategory.jsp");
			dispatcher.forward(request, response);
			break;
		case "delete":
			categoryDAO.delete(Integer.parseInt(request.getParameter("id")));
			response.sendRedirect(request.getContextPath()+"/admin/category");
			break;
		default:
			request.setAttribute("categories", categoryDAO.getList());
			dispatcher=request.getRequestDispatcher("/View/Admin/category/listcategory.jsp");
			dispatcher.forward(request, response);
			break;
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		CategoryDAO categoryDAO=new CategoryDAO();
		String action=request.getParameter("action");
		switch (action) {
		case "add":
			Category category=new Category();
			category.setName(request.getParameter("name"));
			category.setGroup_category_id(Integer.parseInt(request.getParameter("group_category_id")));
			categoryDAO.insert(category);
			response.sendRedirect(request.getContextPath()+"/admin/category");
			break;
		case "edit":
			categoryDAO.update(new Category(Integer.parseInt(request.getParameter("id")),request.getParameter("name"),Integer.parseInt(request.getParameter("group_category_id"))));
			response.sendRedirect(request.getContextPath()+"/admin/category");
			break;
		default:
			break;
		}
	}

}
