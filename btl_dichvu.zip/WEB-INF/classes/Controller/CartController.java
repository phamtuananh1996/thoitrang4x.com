package Controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.ProductDAO;
import Model.Cart;

/**
 * Servlet implementation class CartController
 */
@WebServlet("/addtocart")
public class CartController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CartController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ProductDAO productDAO=new ProductDAO();
		ArrayList<Cart> carts=new ArrayList<>();
		HttpSession session=request.getSession();
		//kiểm tra tồn tải của giỏ hàng
		if(!(session.getAttribute("cart")==null))
		{
			carts=(ArrayList<Cart>) session.getAttribute("cart");
			if(check(carts,Integer.parseInt(request.getParameter("id")))==-1)
			{
				carts.add(new Cart(productDAO.getProduct(Integer.parseInt(request.getParameter("id"))),1));
			}
			else
			{
				int index=check(carts,Integer.parseInt(request.getParameter("id")));
				carts.get(index).setSoluong((carts.get(index).getSoluong())+1);
			}
		}
		else
		{
			carts.add(new Cart(productDAO.getProduct(Integer.parseInt(request.getParameter("id"))),1));
		}
		
		session.setAttribute("cart",carts);
		response.sendRedirect(request.getContextPath()+"/cart");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	private int check(ArrayList<Cart> carts,int id)
	{
		 int index = 0;
		for(Cart item:carts)
		{
			if(item.getProduct().getId()==id)
			{
				return index;
			}
			index++;
		}
		return -1;
	}

}
