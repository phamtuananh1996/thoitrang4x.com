package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.CategoryDAO;
import Model.GroupCategory;
import DAO.GroupCategoryDao;
import Model.Category;

/**
 * Servlet implementation class GroupCategoryController
 */
@WebServlet("/admin/group_category")
public class GroupCategoryController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GroupCategoryController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=(request.getParameter("action")==null)?"index":request.getParameter("action");
		RequestDispatcher dispatcher;
		GroupCategoryDao groupcategoryDao=new GroupCategoryDao();
		switch (action) {
		case "add":
			dispatcher=request.getRequestDispatcher("/View/Admin/group_category/addgroupcategory.jsp");
			dispatcher.forward(request, response);
			break;
		case "edit":
			request.setAttribute("GroupCategory", groupcategoryDao.getGroupCategory(Integer.parseInt(request.getParameter("id"))));
			dispatcher=request.getRequestDispatcher("/View/Admin/group_category/editgroupcategory.jsp");
			dispatcher.forward(request, response);
			break;
		case "delete":
			groupcategoryDao.delete(Integer.parseInt(request.getParameter("id")));
			response.sendRedirect(request.getContextPath()+"/admin/group_category");
			break;
		default:
			request.setAttribute("categories", groupcategoryDao.getList());
			dispatcher=request.getRequestDispatcher("/View/Admin/group_category/listgroupcategory.jsp");
			dispatcher.forward(request, response);
			break;
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		GroupCategoryDao groupCategoryDao=new GroupCategoryDao();
		String action=request.getParameter("action");
		switch (action) {
		case "add":
			GroupCategory groupCategory=new GroupCategory();
			groupCategory.setName(request.getParameter("name"));
			groupCategoryDao.insert(groupCategory);
			response.sendRedirect(request.getContextPath()+"/admin/group_category");
			break;
		case "edit":
			groupCategoryDao.update(new GroupCategory(Integer.parseInt(request.getParameter("id")),request.getParameter("name")));
			response.sendRedirect(request.getContextPath()+"/admin/group_category");
			break;
		default:
			break;
		}
	}

}
