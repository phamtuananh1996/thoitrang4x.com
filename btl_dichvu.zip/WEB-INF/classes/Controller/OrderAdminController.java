package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.OrderDao;

/**
 * Servlet implementation class OrderAdminController
 */
@WebServlet("/admin/order")
public class OrderAdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderAdminController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=(request.getParameter("action")!=null)?request.getParameter("action"):"index";
		RequestDispatcher dispatcher;
		switch (action) {
		case "detail":
			dispatcher=request.getRequestDispatcher("/View/Admin/order/detail.jsp");
			dispatcher.forward(request, response);
			break;
		case "shiper":
			OrderDao orderDao=new OrderDao();
			orderDao.update(Integer.parseInt(request.getParameter("id")));
			response.sendRedirect(request.getContextPath()+"/admin/order");
			break;
		default:
			dispatcher=request.getRequestDispatcher("/View/Admin/order/index.jsp");
			dispatcher.forward(request, response);
			break;
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
