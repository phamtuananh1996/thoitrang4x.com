package Controller;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.FileItemFactory;
import org.apache.tomcat.util.http.fileupload.FileUploadException;
import org.apache.tomcat.util.http.fileupload.RequestContext;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;

import DAO.CategoryDAO;
import DAO.GroupCategoryDao;
import DAO.ProductDAO;
import Model.Product;
import Model.User;

/**
 * Servlet implementation class ProductController
 */

@WebServlet("/admin/product")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
maxFileSize = 1024 * 1024 * 10, // 10MB
maxRequestSize = 1024 * 1024 * 50) // 50MB
public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final String SAVE_DIRECTORY = "image";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=(request.getParameter("action")!=null)?request.getParameter("action"):"index";
		RequestDispatcher dispatcher;
		ProductDAO productDao=new ProductDAO();
		CategoryDAO categoryDao=new CategoryDAO();
		switch (action) {
		case "add":
			 dispatcher=request.getRequestDispatcher("/View/Admin/product/addproduct.jsp");
			 dispatcher.forward(request, response);
			break;
		case "getcategory":
			 int id=Integer.parseInt(request.getParameter("id_groupcategory"));
			 request.setAttribute("categories", categoryDao.getCategoryOfGroup(id));
			 dispatcher=request.getRequestDispatcher("/View/Admin/product/ajax/categoryproduct.jsp");
			 dispatcher.forward(request, response);
			break;
		case "delete":
			int id_product=Integer.parseInt(request.getParameter("id_product"));
			productDao.delete(id_product);
			response.sendRedirect(request.getContextPath()+"/admin/product");
			break;
		case "edit":
			 dispatcher=request.getRequestDispatcher("/View/Admin/product/editproduct.jsp");
			 dispatcher.forward(request, response);
			break;
		default:
			 ArrayList<Product> products=productDao.listProduct();
			 request.setAttribute("listProduct", products);
			 dispatcher=request.getRequestDispatcher("/View/Admin/product/listproduct.jsp");
			 dispatcher.forward(request, response);
			break;
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		String action=(request.getParameter("action")!=null)?request.getParameter("action"):"index";
		RequestDispatcher dispatcher;
		ProductDAO productDao=new ProductDAO();
		Product product=new Product();
		switch (action) {
		case "add":
			product.setCategory_id(Integer.parseInt(request.getParameter("category")));
			product.setName(request.getParameter("name"));
			product.setPrice(Integer.parseInt(request.getParameter("price").trim()));
			product.setSize(request.getParameter("size"));
			product.setHighlights(request.getParameter("highlights"));
			product.setDecription(request.getParameter("decription"));
			product.setImage(upLoad(request));
			productDao.insert(product);
			response.sendRedirect(request.getContextPath()+"/admin/product");
			break;
		case "edit":
			product.setCategory_id(Integer.parseInt(request.getParameter("category")));
			product.setName(request.getParameter("name"));
			product.setId(Integer.parseInt(request.getParameter("id")));
			product.setPrice(Integer.parseInt(request.getParameter("price").trim()));
			product.setSize(request.getParameter("size"));
			product.setHighlights(request.getParameter("highlights"));
			product.setDecription(request.getParameter("decription"));
			if(!upLoad(request).equals(""))
				product.setImage(upLoad(request));
			else
				product.setImage(request.getParameter("image"));
			productDao.update(product);
			response.sendRedirect(request.getContextPath()+"/admin/product");
			break;
		default:
			 dispatcher=request.getRequestDispatcher("/View/Admin/product/listproduct.jsp");
			 dispatcher.forward(request, response);
			break;
		}
	}
	 private String extractFileName(Part part) {
	       // form-data; name="file"; filename="C:\file1.zip"
	       // form-data; name="file"; filename="C:\Note\file2.zip"
	       String contentDisp = part.getHeader("content-disposition");
	       String[] items = contentDisp.split(";");
	       for (String s : items) {
	           if (s.trim().startsWith("filename")) {
	               // C:\file1.zip
	               // C:\Note\file2.zip
	               String clientFileName = s.substring(s.indexOf("=") + 2, s.length() - 1);
	               clientFileName = clientFileName.replace("\\", "/");
	               int i = clientFileName.lastIndexOf('/');
	               // file1.zip
	               // file2.zip
	               return clientFileName.substring(i + 1);
	           }
	       }
	       return null;
	   }
	 private String upLoad(HttpServletRequest request)
	 {
		 try {
		       
			  
	           // Đường dẫn tuyệt đối tới thư mục gốc của web app.
	           //String appPath = request.getServletContext().getContextPath();
			   String appPath = request.getServletContext().getRealPath("");
			   appPath = appPath.replace('\\', '/');
	 
	  
	           // Thư mục để save file tải lên.
	           String fullSavePath = null;
	           if (appPath.endsWith("/")) {
	               fullSavePath = appPath + SAVE_DIRECTORY;
	               
	           } else {
	               fullSavePath = appPath + "/" + SAVE_DIRECTORY;
	           }
	  
	           // Tạo thư mục nếu nó không tồn tại.
	           File fileSaveDir = new File(fullSavePath);
	           if (!fileSaveDir.exists()) {
	               fileSaveDir.mkdir();
	           }
	  
	           // Danh mục các phần đã upload lên (Có thể là nhiều file).
	           for (Part part : request.getParts()) {
	               String fileName = extractFileName(part);
	               if (fileName != null && fileName.length() > 0) {
	                   String filePath = fullSavePath + File.separator + fileName;
	                   part.write(filePath);
	                   return fileName;
	               }
	           }
	           
	           // Upload thành công.
	    
	       } catch (Exception e) {
	           e.printStackTrace();
	           request.setAttribute("errorMessage", "Error: " + e.getMessage());
	       }
		 return "";
	 }
}
