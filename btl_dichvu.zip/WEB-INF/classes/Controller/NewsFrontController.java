package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class NewsFrontController
 */
@WebServlet("/news_list")
public class NewsFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NewsFrontController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=(request.getParameter("action")!=null)?request.getParameter("action"):"index";
		RequestDispatcher dispatcher;
		switch (action) {
		case "detail":
			dispatcher=request.getRequestDispatcher("/View/frontend/news/detailnews.jsp");
			dispatcher.forward(request, response);
			break;

		default:
			dispatcher=request.getRequestDispatcher("/View/frontend/news/listnews.jsp");
			dispatcher.forward(request, response);
			break;
		}
		 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
