package Controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Model.Cart;

/**
 * Servlet implementation class CartdetailController
 */
@WebServlet("/cart")
public class CartdetailController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CartdetailController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=(request.getParameter("action")!=null)?request.getParameter("action"):"index";
		RequestDispatcher dispatcher;
		HttpSession session=request.getSession();
		switch (action) {
		case "deleteall":	
			session.setAttribute("cart", null);
			response.sendRedirect(request.getContextPath()+"/home");
			break;
			
		default:
			dispatcher=request.getRequestDispatcher("/View/frontend/cart/cart.jsp");
			dispatcher.forward(request, response);
			break;
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=(request.getParameter("action")!=null)?request.getParameter("action"):"index";
		RequestDispatcher dispatcher;
		HttpSession session=request.getSession();
		ArrayList<Cart> carts=(ArrayList<Cart>) session.getAttribute("cart");
		switch (action) {
		case "delete":
			if(this.check(carts, Integer.parseInt(request.getParameter("id")))!=-1)
			{
				carts.remove(this.check(carts, Integer.parseInt(request.getParameter("id"))));
				if(carts.size()!=0)
					session.setAttribute("cart", carts);
				else
					session.setAttribute("cart", null);
			}
			break;
		case "update":
			if(this.check(carts, Integer.parseInt(request.getParameter("id")))!=-1)
			{
				Cart cart= carts.get(this.check(carts, Integer.parseInt(request.getParameter("id"))));
				cart.setSoluong(Integer.parseInt(request.getParameter("soluong")));
				carts.set(this.check(carts, Integer.parseInt(request.getParameter("id"))), cart);
				if(carts.size()!=0)
					session.setAttribute("cart", carts);
				else
					session.setAttribute("cart", null);
			}
			break;

		default:
			break;
		}
	}
	private int check(ArrayList<Cart> carts,int id)
	{
		 int index = 0;
		for(Cart item:carts)
		{
			if(item.getProduct().getId()==id)
			{
				return index;
			}
			index++;
		}
		return -1;
	}

}
