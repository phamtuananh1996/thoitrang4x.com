package Controller;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import Rule.GiaThiet;
import Rule.KetLuan;
import Rule.Luat;

/**
 * Servlet implementation class AdvisoryController
 */
@WebServlet("/advisory")
public class AdvisoryController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdvisoryController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher=request.getRequestDispatcher("View/frontend/advisory/index.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ArrayList<Luat> luats=ReadJSONFile(request);
		GiaThiet giaThiet=new GiaThiet(request.getParameter("can_nang"),request.getParameter("chieu_cao"),request.getParameter("do_tuoi")!=null?request.getParameter("do_tuoi"):"");
		Luat luat1=new Luat(giaThiet,null);
		String size="";
		ArrayList<KetLuan> ketLuans=new ArrayList<>();
		for (Luat item:luats) {		
			if((luat1.getGiaThiet().getC().equals(item.getGiaThiet().getC()))&&(luat1.getGiaThiet().getN().equals(item.getGiaThiet().getN()))&&(luat1.getGiaThiet().getT().equals(item.getGiaThiet().getT()))){
				ketLuans=item.getKetLuan();
				int Wmax=max(item.getKetLuan());
				 size= item.getKetLuan().get(Wmax).getSize();
			}
		}
		request.setAttribute("size", size);
		request.setAttribute("sizes", ketLuans);
		RequestDispatcher dispatcher=request.getRequestDispatcher("View/frontend/advisory/advisory.jsp");
		dispatcher.forward(request, response);
	}
	private ArrayList<Luat> ReadJSONFile(HttpServletRequest request)
	{
		 JSONParser parser = new JSONParser();

	        try {
	            Object obj = parser.parse(new FileReader(request.getServletContext().getRealPath("")+"/Luats.json"));
	            JSONArray array = (JSONArray) obj;
	            ArrayList<Luat> luats=new ArrayList<>();
	            for (int i = 0; i < array.size(); i++) {
	            	JSONObject jsonObject = (JSONObject) array.get(i);
	            	JSONObject giathiet=(JSONObject) jsonObject.get("Giathiet");
	            	GiaThiet giaThiet=new GiaThiet((String)giathiet.get("N"),(String)giathiet.get("C"),(String)giathiet.get("T"));
	            	JSONArray kl = (JSONArray) jsonObject.get("Ketluans");
	            	ArrayList<KetLuan> ketLuans=new ArrayList<>();
	            	for (int j = 0; j < kl.size(); j++) {
	            		JSONObject kls = (JSONObject) kl.get(j);
	            		ketLuans.add(new KetLuan((int) (long)kls.get("Weight"),(String)kls.get("Size")));
					}
	            	luats.add(new Luat(giaThiet,ketLuans));
	            	
				}
	            return luats;
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        } catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        return null;
	}
	
	private int max(ArrayList<KetLuan> ketLuans)
	{
		int vt=-1;
		int kl=0;
			for (int i = 0; i < ketLuans.size(); i++) {
				if(ketLuans.get(i).getWeight()>kl)
				{
					kl=ketLuans.get(i).getWeight();
					vt=i;
				}
			}
		return vt;
	}
	

}
