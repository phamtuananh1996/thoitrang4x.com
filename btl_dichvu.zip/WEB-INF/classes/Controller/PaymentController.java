package Controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import DAO.OrderDao;
import Model.Cart;
import Model.Order;

/**
 * Servlet implementation class PaymentController
 */
@WebServlet("/Payment")
public class PaymentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private OrderDao orderDao=new OrderDao();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PaymentController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		if(session.getAttribute("cart")!=null)
		{
			RequestDispatcher dispatcher=request.getRequestDispatcher("/View/frontend/payment/payment.jsp");
			dispatcher.forward(request, response);
		}
		else
		{
			response.sendRedirect(request.getContextPath()+"/home");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		ArrayList<Cart> carts=(ArrayList<Cart>) session.getAttribute("cart");
		int total=0;
		for(Cart item:carts){
			total+=item.getSoluong()*item.getProduct().getPrice();
		}
		Order order=new Order();
		order.setAddress(request.getParameter("address"));
		order.setEmail(request.getParameter("email"));
		order.setPhone(request.getParameter("phone"));
		order.setName(request.getParameter("name"));
		order.setTotal(total);
		order.setStatus(0);
		int id_order=this.orderDao.insert(order);
		for(Cart item:carts){
			this.orderDao.insertOrderDetail(id_order, item.getProduct().getId(), item.getSoluong());
		}
		session.setAttribute("cart", null);
		response.sendRedirect(request.getContextPath()+"/success");
	}

}
