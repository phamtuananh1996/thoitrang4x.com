package Controller;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import DAO.UserDAO;
import Model.User;

/**
 * Servlet implementation class UserController
 */
@WebServlet("/admin/user")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=(request.getParameter("action")!=null)?request.getParameter("action"):"index";
		RequestDispatcher dispatcher;
		UserDAO dao=new UserDAO();
		User user=new User();
		switch (action) {
		case "add":
			dispatcher=request.getRequestDispatcher("/View/Admin/user/adduser.jsp");
			dispatcher.forward(request, response);
			break;
		case "edit":
			user=dao.getUser(request.getParameter("id"));
			request.setAttribute("user", user);
			dispatcher=request.getRequestDispatcher("/View/Admin/user/edituser.jsp");
			dispatcher.forward(request, response);
			break;
		case "delete":
			if(dao.delete(Integer.parseInt(request.getParameter("id"))))
				response.sendRedirect(request.getContextPath()+"/admin/user");
			else
				response.sendRedirect(request.getContextPath()+"/admin/user");
			break;
		default:
			ArrayList<User> users=new ArrayList<>();
			users=dao.getList();
			request.setAttribute("users", users);
			dispatcher=request.getRequestDispatcher("/View/Admin/user/listuser.jsp");
			dispatcher.forward(request, response);
		}
		
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		UserDAO dao=new UserDAO();
		switch (action) {
		case "edit":
			System.out.println("ok");
			dao.update(new User(Integer.parseInt(request.getParameter("id")),request.getParameter("password"),request.getParameter("email"),request.getParameter("fullname"),1));
			response.sendRedirect(request.getContextPath()+"/admin/user");
			break;
		case "add":
			if(dao.insert(new User(0,request.getParameter("password"),request.getParameter("email"),request.getParameter("fullname"),1)))
			{
				response.sendRedirect(request.getContextPath()+"/admin/user");
			}
			else
			{
				response.sendRedirect(request.getContextPath()+"/admin/user");
			}
			
			break;
		default:
			break;
		}
	}

}
