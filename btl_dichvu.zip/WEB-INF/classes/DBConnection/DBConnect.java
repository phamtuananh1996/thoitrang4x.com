package DBConnection;

import java.sql.*;

public class DBConnect {
	public static Connection createConnection()
	{
		Connection conn=null;
		String url="JDBC:mysql://127.0.0.1:3306/xthoitra_data?useUnicode=true&characterEncoding=UTF-8";
		String userName="xthoitra_nhom1";
		String passWord="k=TG?-+8hSTU";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection(url,userName,passWord);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
	}
}
