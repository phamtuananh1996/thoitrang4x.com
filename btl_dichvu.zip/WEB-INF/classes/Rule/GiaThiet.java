package Rule;

public class GiaThiet {
	private String N;
	private String C;
	private String T;
	
	public GiaThiet() {
		super();
	}
	public GiaThiet(String n, String c, String t) {
		super();
		N = n;
		C = c;
		T = t;
	}
	public String getN() {
		return N;
	}
	public void setN(String n) {
		N = n;
	}
	public String getC() {
		return C;
	}
	public void setC(String c) {
		C = c;
	}
	public String getT() {
		return T;
	}
	public void setT(String t) {
		T = t;
	}
	
}
