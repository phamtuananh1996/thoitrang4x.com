package Rule;

import java.util.ArrayList;

public class Luat {
	private GiaThiet giaThiet ;
	private ArrayList<KetLuan>  ketLuan =new ArrayList<>();
	public Luat(GiaThiet giaThiet, ArrayList<KetLuan> ketLuan) {
		super();
		this.giaThiet = giaThiet;
		this.ketLuan = ketLuan;
	}
	public GiaThiet getGiaThiet() {
		return giaThiet;
	}
	public void setGiaThiet(GiaThiet giaThiet) {
		this.giaThiet = giaThiet;
	}
	public ArrayList<KetLuan> getKetLuan() {
		return ketLuan;
	}
	public void setKetLuan(ArrayList<KetLuan> ketLuan) {
		this.ketLuan = ketLuan;
	}
	public Luat() {
		super();
	}
	
}
