package Rule;

import java.util.ArrayList;

public class KetLuan {
	private int Weight;
	private String Size;
	public int getWeight() {
		return Weight;
	}
	public void setWeight(int weight) {
		Weight = weight;
	}
	public String getSize() {
		return Size;
	}
	public void setSize(String size) {
		Size = size;
	}
	public KetLuan(int weight, String size) {
		super();
		Weight = weight;
		Size = size;
	}
	public KetLuan() {
		super();
	}
}
