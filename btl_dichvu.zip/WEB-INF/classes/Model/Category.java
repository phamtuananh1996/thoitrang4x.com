package Model;

public class Category {
	private String name;
	private int group_category_id;
	private int id;
	public Category(int id,String name,int group_category_id ) {
		super();
		this.id = id;
		this.name = name;
		this.group_category_id = group_category_id;
	}
	public int getGroup_category_id() {
		return group_category_id;
	}
	public void setGroup_category_id(int group_category_id) {
		this.group_category_id = group_category_id;
	}
	public Category() {
	
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
}
