package Model;

import java.sql.Date;

public class Product {
	private int id;
	private int category_id;
	private String name;
	private String image;
	private String decription;
	private String size;
	private int price;
	private Date date;
	private int view;
	private String highlights;
	public Product(int id, int category_id, String name, String image, String decription, int price, Date date,
			int view, String highlights) {
		super();
		this.id = id;
		this.category_id = category_id;
		this.name = name;
		this.image = image;
		this.decription = decription;
		this.price = price;
		this.date = date;
		this.view = view;
		this.highlights = highlights;
	}
	public Product() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public int getCategory_id() {
		return category_id;
	}
	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getDecription() {
		return decription;
	}
	public void setDecription(String decription) {
		this.decription = decription;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getView() {
		return view;
	}
	public void setView(int view) {
		this.view = view;
	}
	public String getHighlights() {
		return highlights;
	}
	public void setHighlights(String highlights) {
		this.highlights = highlights;
	}
	
}
